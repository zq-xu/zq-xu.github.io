kubectl get pods -nxzq |grep Completed|awk '{print $1}'|xargs kubectl delete pod -nxzq 
