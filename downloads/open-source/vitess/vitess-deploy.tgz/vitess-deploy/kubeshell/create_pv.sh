kubectl create -f yaml/pv1.yaml
kubectl create -f yaml/pv2.yaml
kubectl create -f yaml/pv3.yaml
