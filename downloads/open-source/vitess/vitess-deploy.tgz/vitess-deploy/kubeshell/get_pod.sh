kubectl get pods -nxzq $*
