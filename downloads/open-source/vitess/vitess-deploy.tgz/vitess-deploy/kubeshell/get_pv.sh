kubectl get pv -nxzq|grep pv-hostpath-
