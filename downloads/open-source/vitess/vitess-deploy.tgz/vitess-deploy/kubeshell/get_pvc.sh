kubectl get pvc -nxzq $*
