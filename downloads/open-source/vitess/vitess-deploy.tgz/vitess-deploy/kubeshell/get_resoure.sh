kubectl get pods,jobs,svc,pvc -nxzq -owide
