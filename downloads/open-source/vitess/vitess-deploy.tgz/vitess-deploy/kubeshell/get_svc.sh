kubectl get svc -nxzq $*
